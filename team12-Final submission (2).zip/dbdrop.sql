SET FOREIGN_KEY_CHECKS = 0; -- disable foreign keys

drop table Restaurants;
drop table Menu;
drop table Orders;
drop table Reviews;
drop table Customers;
drop table Payments;
drop table Reservations;
drop table Staff;
drop table Category;
drop table Ranking;
drop table Inventory;
drop table Discount;

-- SHOW TABLES FROM team12; -- check if it's all deleted