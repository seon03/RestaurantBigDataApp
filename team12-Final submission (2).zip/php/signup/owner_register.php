<?php

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // MySQL 데이터베이스 연결
    $mysqli = new mysqli("localhost", "team12", "team12", "team12");

    // 연결 확인
    if ($mysqli->connect_errno) {
        echo "Failed to connect to MySQL: " . $mysqli->connect_error;
        exit();
    }

    // Escape user inputs for security
    $restaurantName = mysqli_real_escape_string($mysqli, $_POST['restaurantName']);
    $ownerEmail = mysqli_real_escape_string($mysqli, $_POST['ownerEmail']);
    $ownerPassword = mysqli_real_escape_string($mysqli, $_POST['ownerPassword']);
    $ownerName = mysqli_real_escape_string($mysqli, $_POST['ownerName']);
    $ownerPhone = mysqli_real_escape_string($mysqli, $_POST['ownerPhone']);

    // Check if the restaurant already exists
    $checkRestaurantQuery = "SELECT restaurant_id FROM Restaurants WHERE restaurant_name = '$restaurantName'";
    $result = $mysqli->query($checkRestaurantQuery);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $restaurantId = $row['restaurant_id'];

        // Generate staff_id
        // Generate staff_id
        $staffIdQuery = "SELECT CONCAT('S', LPAD(MAX(CAST(SUBSTRING(staff_id, 2) AS UNSIGNED)) + 1, 2, '0')) AS next_staff_id FROM Staff";
        $resultStaffId = $mysqli->query($staffIdQuery);

        if ($resultStaffId->num_rows > 0) {
            $rowStaffId = $resultStaffId->fetch_assoc();
            $staffId = $rowStaffId['next_staff_id'];
        } else {
            $staffId = 'S01';
        }

        // SQL query to insert data into Staff table
        $sql = "INSERT INTO Staff (staff_id, restaurant_id, staff_name, staff_number, staff_email) 
                VALUES ('$staffId', '$restaurantId', '$ownerName', '$ownerPhone', '$ownerEmail')";

        if ($mysqli->query($sql) === TRUE) {
            echo "New record created successfully";
        } else {
            echo "Error: " . $sql . "<br>" . $mysqli->error;
        }
    } else {
        echo "Error: Restaurant not found";
    }

    // Close the connection
    $mysqli->close();
}

?>

<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>사장 회원가입</title>
    <link rel="stylesheet" type="text/css" href="signup_style.css">
</head>
<body>

    <h1>Sign up as a owner</h1>

    <form class="signup-form" method="post" action="owner_register.php">
        <input type="text" name="restaurantName" class="signup-input" placeholder="restaurant name" required>
        <input type="email" name="ownerEmail" class="signup-input" placeholder="Email" required>
        <input type="password" name="ownerPassword" class="signup-input" placeholder="password" required>
        <input type="text" name="ownerName" class="signup-input" placeholder="name" required>
        <input type="tel" name="ownerPhone" class="signup-input" placeholder="phone number" required>

        <button type="submit" class="signup-button">Sign up</button>
    </form>

</body>
</html>
