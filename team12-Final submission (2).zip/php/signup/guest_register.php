<?php

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {

 // MySQL 데이터베이스 연결
    $mysqli = new mysqli("localhost", "team12", "team12", "team12");

// 연결 확인
    if ($mysqli->connect_errno) {
    echo "Failed to connect to MySQL: " . $mysqli->connect_error;
    exit();
}

    // Escape user inputs for security
    $guestEmail = mysqli_real_escape_string($mysqli, $_POST['guestEmail']);
    $guestPassword = mysqli_real_escape_string($mysqli, $_POST['guestPassword']);
    $guestName = mysqli_real_escape_string($mysqli, $_POST['guestName']);
    $guestPhone = mysqli_real_escape_string($mysqli, $_POST['guestPhone']);

    // Get the last customer_id from the database
    $getLastIdQuery = "SELECT customer_id FROM Customers ORDER BY CAST(SUBSTRING(customer_id, 9) AS UNSIGNED) DESC LIMIT 1";
    $result = $mysqli->query($getLastIdQuery);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $lastCustomerId = $row['customer_id'];

        // Extract the numeric part
        $numericPart = intval(preg_replace('/[^0-9]/', '', $lastCustomerId));

        // Increment the numeric part by 1
        $nextNumericPart = $numericPart + 1;

        // Construct the new customer_id
        $nextCustomerId = 'customer' . $nextNumericPart ;
    } else {
        // If no records are present, start with customer(1)
        $nextCustomerId = 'customer(1)';
    }

    // SQL query to insert data into Customers table
    $sql = "INSERT INTO Customers (customer_id, customer_name, email, phone) 
            VALUES ('$nextCustomerId', '$guestName', '$guestEmail', '$guestPhone')";

    if ($mysqli->query($sql) === TRUE) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $mysqli->error;
    }

    // Close the connection
    $mysqli->close();
}
?>

<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>손님 회원가입</title>
    <link rel="stylesheet" type="text/css" href="signup_style.css">
</head>
<body>

    <h1>Sign up as a guest</h1>

    <form class="signup-form" method="post" action="guest_register.php">
        <input type="email" name="guestEmail" class="signup-input" placeholder="Email" required>
        <input type="password" name="guestPassword" class="signup-input" placeholder="password" required>
        <input type="text" name="guestName" class="signup-input" placeholder="name" required>
        <input type="tel" name="guestPhone" class="signup-input" placeholder="phone number" required>

        <button type="submit" class="signup-button">Sign up</button>
    </form>

</body>
</html>
