<?php
// MySQL 데이터베이스 연결
$mysqli = new mysqli("localhost", "team12", "team12", "team12");

// 연결 확인
if ($mysqli->connect_errno) {
    echo "Failed to connect to MySQL: " . $mysqli->connect_error;
    exit();
}

// 사용자 입력 받기
$searchInput = isset($_GET['searchInput']) ? $_GET['searchInput'] : '';

// 리뷰 데이터, 레스토랑 이름, 고객 이름 가져오기 (조인 수행)
$query = "SELECT reviews.review_id, restaurants.restaurant_name, reviews.comment, reviews.rating, customers.customer_name
        FROM reviews
        JOIN restaurants ON reviews.restaurant_id = restaurants.restaurant_id
        JOIN customers ON reviews.customer_id = customers.customer_id
        JOIN Category ON restaurants.restaurant_id = Category.restaurant_id
        WHERE restaurants.restaurant_name LIKE ? OR reviews.rating LIKE ? OR Category.category_name LIKE ?";
$stmt = $mysqli->prepare($query);

// 검색어에 '%'를 추가하여 LIKE 연산을 수행합니다.
$searchInput = '%' . $searchInput . '%';

// 바인딩 및 실행
$stmt->bind_param("sss", $searchInput, $searchInput, $searchInput);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>검색 결과</title>
    <style>
        /* styles.css */

    .list {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    .list th {
        height: 30px;
        text-align: center;
        border: 1px solid #e1e1e1;
        background-color: #3498db;
        color: white;
        padding: 8px;
    }

    .list td {
        height: 30px;
        text-align: center;
        border: 1px solid #e1e1e1;
        padding: 8px;
    }

    .list tr:nth-child(even) {
        background-color: lightgoldenrodyellow;
    }


    .pagination {
        text-align: center;
        margin-top: 20px;
    }

    .pagination a, .pagination strong {
        margin-right: 5px;
        padding: 6px 10px 6px 10px;
        color: #3498db;
        text-decoration: none;
        font: bold 14px/normal Verdana;
    }

    .pagination strong {
        color: white;
        background: #3498db;
        border-radius: 15px;
    }
    .signup-button-container {
    text-align: center;
    margin-top: 20px; 
    }

    .back-button {
        background-color: #3498db; 
        color: white; 
        padding: 10px 20px; 
        font-size: 16px; 
        border: none; 
        border-radius: 5px;
        cursor: pointer; 
        transition: background-color 0.3s; 
    }

    .back-button:hover {
        background-color: #3498db;
    }

</style>
</head>
<body>
    
    <h1>Search Results</h1>

    <form action="search.php" method="get">
        <div class="search-container">
            <input type="text" name="searchInput" id="searchInput" placeholder="name/rate/category" value="<?php echo htmlspecialchars($searchInput); ?>">
            <button type="submit">search</button>
            <button type="button" class="back-button" onClick="location.href='../review_list_page/review_view.php'">Go back</button>
        </div>
    </form>

    <table class="list" border="0" align="center" cellspacing="0" cellpadding="0" style="width: 100%;">
        <colgroup>
            <col width="5%" />
            <col width="10%" />
            <col width="50%" />
            <col width="10%" />
            <col width="10%" />
        </colgroup>
        <tr>
            <th>No</th>
            <th>식당</th>
            <th>코멘트</th>
            <th>평점</th>
            <th>작성자</th>
        </tr>
        <tbody>

            <?php
            // 가져온 데이터를 반복문을 사용하여 출력
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>" . $row['review_id'] . "</td>";
                echo "<td>" . $row['restaurant_name'] . "</td>";
                echo "<td>" . $row['comment'] . "</td>";
                echo "<td>" . $row['rating'] . "</td>";
                echo "<td>" . $row['customer_name'] . "</td>";
                echo "</tr>";
            }

            // 연결 종료
            $stmt->close();
            $mysqli->close();
            ?>

        </tbody>
    </table>
    <div class="signup-button-container">
        
    </div>

</body>
</html>
