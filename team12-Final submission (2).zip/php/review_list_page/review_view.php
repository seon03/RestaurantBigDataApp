<?php
function paging($write_pages, $cur_page, $total_page, $url) {
    $str = "";
    if ($cur_page > 1) {
        $str .= "<a href='" . $url . "1' class='pre_all'>처음</a>";
        $str .= "<a href='" . $url . ($cur_page-1) . "' class='pre'>이전</a>";
    } else {
        $str .= "";
    }
    $start_page = @( ( (int)( ($cur_page - 1 ) / $write_pages ) ) * $write_pages ) + 1;
    $end_page = $start_page + $write_pages - 1;

    if ($end_page >= $total_page) $end_page = $total_page;

    if ($total_page > 1) {
        for ($k=$start_page;$k<=$end_page;$k++) {
            if(($cur_page-2) <= $k  && $k < ($cur_page+3)) {
                if ($cur_page != $k) { 
                    $str .= "<a href='$url$k'  class='numBox;'>$k</a>";
                } else {
                    $str .= "<strong>$k</strong>"; 
                }
            }
        }
    }

    if ($cur_page < $total_page) {
        $str .= "<a href='$url" . ($cur_page+1) . "' class='next'>다음</a>";
        $str .= "<a href='$url$total_page' class='next_all'>맨끝</a>";
    } else {
        $str .= "";
    }

    $str .= "";

    return $str;
}

// MySQL 데이터베이스 연결
$mysqli = mysqli_connect("localhost", "team12", "team12", "team12");

// 연결 확인
if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
    exit();
}

// 페이징 변수
$page = isset($_GET['page']) ? $_GET['page'] : 1;
$itemsPerPage = 10;
$offset = ($page - 1) * $itemsPerPage;

// 리뷰 데이터, 레스토랑 이름, 고객 이름 가져오기 (조인 수행)
$query = "SELECT reviews.review_id, restaurants.restaurant_name, reviews.comment, reviews.rating, customers.customer_name
        FROM reviews
        JOIN restaurants ON reviews.restaurant_id = restaurants.restaurant_id
        JOIN customers ON reviews.customer_id = customers.customer_id
        LIMIT $offset, $itemsPerPage";
$result = mysqli_query($mysqli, $query);

// 페이징을 위한 전체 레코드 수 가져오기
$totalQuery = "SELECT COUNT(*) as total FROM reviews";
$totalResult = mysqli_query($mysqli, $totalQuery);
$totalRow = mysqli_fetch_assoc($totalResult);
$totalRecords = $totalRow['total'];
$totalPages = ceil($totalRecords / $itemsPerPage);

// 출력을 시작
?>

<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>리뷰 목록</title>
    
    <style>
        /* styles.css */

    .list {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    .list th {
        height: 30px;
        text-align: center;
        border: 1px solid #e1e1e1;
        background-color: #3498db;
        color: white;
        padding: 8px;
    }

    .list td {
        height: 30px;
        text-align: center;
        border: 1px solid #e1e1e1;
        padding: 8px;
    }

    .list tr:nth-child(even) {
        background-color: lightgoldenrodyellow;
    }


    .pagination {
        text-align: center;
        margin-top: 20px;
    }

    .pagination a, .pagination strong {
        margin-right: 5px;
        padding: 6px 10px 6px 10px;
        color: #3498db;
        text-decoration: none;
        font: bold 14px/normal Verdana;
    }

    .pagination strong {
        color: white;
        background: #3498db;
        border-radius: 15px;
    }

    .back-home {
        background-color: #3498db; 
        color: white; 
        padding: 10px 20px; 
        font-size: 16px; 
        border: none; 
        border-radius: 5px;
        cursor: pointer; 
        transition: background-color 0.3s; 
    }

    .write {
        background-color: #3498db; 
        color: white; 
        padding: 10px 20px; 
        font-size: 16px; 
        border: none; 
        border-radius: 5px;
        cursor: pointer; 
        transition: background-color 0.3s; 
    }
</style>
</head>
<body>
    
    <h1>View reviews</h1>

    <form action="search.php" method="get">
        <div class="search-container">
            <input type="text" name="searchInput" id="searchInput" placeholder="name/rate/category">
            <button type="submit">Search</button>
            <button type="button" class="back-home" onClick="location.href='../home_page/home.php'">Go Home</button>
            <button type="button" class="write" onClick="location.href='../review_post/reviewwrite.php'">Write Review</button>
        </div>
    </form>

    <table class="list" border="0" align="center" cellspacing="0" cellpadding="0" style="width: 100%;">
    <colgroup>
        <col width="5%" />
        <col width="10%" />
        <col width="50%" />
        <col width="10%" />
        <col width="10%" />
    </colgroup>
    <tr>
        <th>No</th>
        <th>Restaurant</th>
        <th>Comment</th>
        <th>Rate</th>
        <th>Writer</th>
    </tr>
    <tbody>
        <?php
        // 가져온 데이터를 반복문을 사용하여 출력
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>" . $row['review_id'] . "</td>";
            echo "<td>" . $row['restaurant_name'] . "</td>";
            echo "<td>" . $row['comment'] . "</td>";
            echo "<td>" . $row['rating'] . "</td>";
            echo "<td>" . $row['customer_name'] . "</td>";
            echo "</tr>";
        }
        ?>
    </tbody>
</table>

<div class='pagination' id='pagination'>
    <?php
    // 페이징 출력
    echo paging(3, $page, $totalPages, $_SERVER['PHP_SELF']."?page=");
    ?>
</div>

<?php
// 연결 종료
mysqli_close($mysqli);
?>

</body>
</html>
