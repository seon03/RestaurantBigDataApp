<?php
// 연결
$mysqli = new mysqli("localhost", "team12", "team12", "team12");

// 연결 확인
if ($mysqli->connect_errno) {
    echo "Failed to connect to MySQL: " . $mysqli->connect_error;
    exit();
}

// admin.php로부터 전달받은 값
if (isset($_POST['menu'])) {$menu = $_POST['menu'];}
if (isset($_POST['quantity'])) {$quantity = $_POST['quantity'];}
if (isset($_POST['tabId'])) {$tabID = $_POST['tabId'];}
if (isset($_POST['selectedCheckboxValue'])) {$dataID = $_POST['selectedCheckboxValue'];}
if (isset($_POST['time'])) {$time = $_POST['time'];}
if (isset($_POST['number'])) {$number = $_POST['number'];}
if (isset($_POST['staffName'])) {$staffName = $_POST['staffName'];}
if (isset($_POST['staffPhone'])) {$staffPhone = $_POST['staffPhone'];}

// Process each case based on $tabID
switch ($tabID) {
    case 'tab-1':
        $query = "UPDATE orders SET quantity = ? WHERE order_id = ?";
    
        $stmt = $mysqli->prepare($query);

        // Assuming $dataID is the order_id and $quantity is the new quantity
        $stmt->bind_param("is", $quantity, $dataID);
        $stmt->execute();

        if ($stmt->affected_rows > 0) {
            echo "Update successful!";
        } else {
            echo "Update failed.";
        }
        $stmt->close();
        

        break;
        

    case 'tab-2':
        $query = "UPDATE inventory SET item_name = ?, quantity = ? WHERE inventory_id = ?";
    
        $stmt = $mysqli->prepare($query);

        // Assuming $dataID is the inventory_id, $menu is the new item_name, and $quantity is the new quantity
        $stmt->bind_param("sis", $menu, $quantity, $dataID);
        $stmt->execute();

        if ($stmt->affected_rows > 0) {
            echo "Update successful!";
        } else {
            echo "Update failed.";
        }
        $stmt->close();
            
        
        break;
        

    case 'tab-4':
        $query = "UPDATE reservations SET reservation_time = ?, num_guests = ? WHERE reservation_id = ?";
    
        $stmt = $mysqli->prepare($query);

        $stmt->bind_param("sis", $time, $number, $dataID);
        $stmt->execute();

        if ($stmt->affected_rows > 0) {
            echo "Update successful!";
        } else {
            echo "Update failed.";
        }
        $stmt->close();
        
        break;

    case 'tab-5':
        $query = "UPDATE staff SET staff_name = ?, staff_number = ? WHERE staff_id = ?";
    
        $stmt = $mysqli->prepare($query);

        $stmt->bind_param("sss", $staffName, $staffPhone, $dataID);
        $stmt->execute();

        if ($stmt->affected_rows > 0) {
            echo "Update successful!";
        } else {
            echo "Update failed.";
        }
        $stmt->close();
        
        break;

    default:
        echo "Invalid tab ID";
        break;
}

// Close the database connection
$mysqli->close();
?>

<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>수정 확인</title>

</head>
<body>
    <button type="button" onclick="goBack();">Go back</button>
    <script>
        // JavaScript를 사용하여 뒤로가기
        function goBack() {
            // 이전 페이지로 이동
            location.href = document.referrer;
        }
    </script>
</body>