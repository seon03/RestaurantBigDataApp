$(document).ready(function() {
    // 초기 상태
    $('.tab-content').hide();
    $('.tab-content.current').show();

    // 클릭 이벤트
    $('.tab-link').click(function() {
        // current 지우기
        $('.tab-link').removeClass('current');
        $('.tab-content').removeClass('current').hide();

        // 클릭된 tab을 current로 만들어 보이게 하기
        const tabId = $(this).data('tab');
        $(this).addClass('current');
        $('#' + tabId).addClass('current').fadeIn();

        return false; 
    });
});
