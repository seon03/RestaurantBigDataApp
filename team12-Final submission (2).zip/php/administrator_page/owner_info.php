<?php
// Database connection
$mysqli = new mysqli("localhost", "team12", "team12", "team12");

// Check connection
if ($mysqli->connect_errno) {
    echo "Failed to connect to MySQL: " . $mysqli->connect_error;
    exit();
}

// Retrieve user_email from the query parameters
$user_email = isset($_GET['user_email']) ? $_GET['user_email'] : "";

// Query to retrieve restaurant name
$query = "SELECT r.restaurant_name
          FROM staff s
          JOIN restaurants r ON s.restaurant_id = r.restaurant_id
          WHERE s.staff_email = ?";
$stmt = $mysqli->prepare($query);
$stmt->bind_param("s", $user_email);
$stmt->execute();
$stmt->bind_result($restaurant_name);

// Fetch the result
$stmt->fetch();

// Close the statement, but don't close the connection here
$stmt->close();
?>
