<?php
// sql 연결, 음식점 이름 받아오기, email 받아오기
include('owner_info.php');

// 음식점 이름으로 restaurant_id 찾기
$restaurantQuery = "SELECT restaurant_id FROM restaurants WHERE restaurant_name = ?";
$restaurantStmt = $mysqli->prepare($restaurantQuery);
$restaurantStmt->bind_param("s", $restaurant_name);
$restaurantStmt->execute();
$restaurantStmt->bind_result($restaurant_id);
$restaurantStmt->fetch();
$restaurantStmt->close();

// Orders table에서 데이터 받아오기
$orderQuery = "SELECT orders.order_id, customers.customer_name, menu.item_name, orders.quantity, orders.order_time
               FROM orders
               JOIN customers ON orders.customer_id = customers.customer_id
               JOIN menu ON orders.menu_id = menu.menu_id
               WHERE orders.restaurant_id = ?";

$orderStmt = $mysqli->prepare($orderQuery);
$orderStmt->bind_param("s", $restaurant_id); //주의-restaurant_id는 string
$orderStmt->execute();
$orderResult = $orderStmt->get_result();


// Roll up: 월별 주문 총 수량
$rollupQuery = "SELECT DATE_FORMAT(orders.order_time, '%Y-%m') AS order_month, SUM(orders.quantity) AS total_quantity
               FROM orders
               WHERE orders.restaurant_id = ?
               GROUP BY order_month
               ORDER BY order_month";

$rollupStmt = $mysqli->prepare($rollupQuery);
$rollupStmt->bind_param("s", $restaurant_id);
$rollupStmt->execute();
$rollupResult = $rollupStmt->get_result();

echo "<h2>Order Statistics</h2>";
echo "<table border='1'>";
echo "<tr><th></th><th>Monthly</th></tr>"; // Remove the Monthly column header

// Roll up 출력
while ($rollupRow = $rollupResult->fetch_assoc()) {
    echo "<tr>";
    echo "<td>Total Order Quantity</td>";
    echo "<td>" . $rollupRow['total_quantity'] . "</td>";
    echo "</tr>";
}

echo "</table>";


// Drill down into menu items for a particular restaurant
$drilldownQuery = "SELECT menu.item_name, SUM(orders.quantity) AS total_quantity
                   FROM orders
                   JOIN menu ON orders.menu_id = menu.menu_id
                   WHERE orders.restaurant_id = ?
                   GROUP BY menu.item_name
                   ORDER BY menu.item_name";

$drilldownStmt = $mysqli->prepare($drilldownQuery);
$drilldownStmt->bind_param("s", $restaurant_id);
$drilldownStmt->execute();
$drilldownResult = $drilldownStmt->get_result();

// 출력
echo "<table border='1'>";
echo "<tr><th>Menu Item</th><th>Total Quantity</th></tr>";

// Drill down 출력
while ($drilldownRow = $drilldownResult->fetch_assoc()) {
    echo "<tr>";
    echo "<td>" . $drilldownRow['item_name'] . "</td>";
    echo "<td>" . $drilldownRow['total_quantity'] . "</td>";
    echo "</tr>";
}

echo "</table>";



// 연결 해제
$mysqli->close();
?>

<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>삽입 확인</title>

</head>
<body>
    <button type="button" onclick="goBack();">Go back</button>
    <script>
        // JavaScript를 사용하여 뒤로가기
        function goBack() {
            // 이전 페이지로 이동
            location.href = document.referrer;
        }
    </script>
</body>