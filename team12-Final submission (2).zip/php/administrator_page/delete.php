<?php
// 연결
$mysqli = new mysqli("localhost", "team12", "team12", "team12");

// 연결 확인
if ($mysqli->connect_errno) {
    echo "Failed to connect to MySQL: " . $mysqli->connect_error;
    exit();
}

// admin.php로부터 전달받은 값
$selectedTabId = $_POST['selectedTabId'];
$selectedCheckboxValue = $_POST['selectedCheckboxValue'];

// 쉼표로 자르기
$tabIdArray = explode(",", $selectedTabId);
$tabID = $tabIdArray[0];
$checkboxValues = explode(",", $selectedCheckboxValue);


// Process each case based on $tabID
switch ($tabID) {
    case 'tab-1':
        foreach ($checkboxValues as $orderId) {
            // Use prepared statements to prevent SQL injection
            $stmt = $mysqli->prepare("SELECT customers.customer_name, menu.item_name
                                       FROM orders
                                       JOIN customers ON orders.customer_id = customers.customer_id
                                       JOIN menu ON orders.menu_id = menu.menu_id
                                       WHERE orders.order_id = ?");
            $stmt->bind_param("s", $orderId);
            $stmt->execute();
            $stmt->bind_result($customerName, $itemName);
            
            // Fetch customer_name and item_name
            if ($stmt->fetch()) {
                // Display the deleted order details
                echo "Deleted Order ID: " . $orderId . "<br>";
                echo "Customer Name: " . $customerName . "<br>";
                echo "Item Name: " . $itemName . "<br>";
    
                // Close the statement
                $stmt->close();
    
                // Delete the order
                $deleteStmt = $mysqli->prepare("DELETE FROM orders WHERE order_id = ?");
                $deleteStmt->bind_param("s", $orderId);
                $deleteStmt->execute();
                $deleteStmt->close();
                
                echo "<br>"; // Add a line break for better readability
            } else {
                echo "한 번에 하나만 지울 수 있습니다. " . $stmt->error;
            }
        }
        break;
        

    case 'tab-2':
        foreach ($checkboxValues as $inventoryId) {
            // Use prepared statements to prevent SQL injection
            $stmt = $mysqli->prepare("SELECT item_name, quantity
                                        FROM inventory
                                        WHERE inventory_id = ?");
            $stmt->bind_param("s", $inventoryId);
            $stmt->execute();
            $stmt->bind_result($itemName, $quantity);
            
            // Fetch customer_name and item_name
            if ($stmt->fetch()) {
                // Display the deleted order details
                echo "Deleted inventory ID: " . $inventoryId . "<br>";
                echo "Item Name: " . $itemName . "<br>";
                echo "Quantity: " . $quantity . "<br>";
    
                // Close the statement
                $stmt->close();
    
                // Delete the inventory
                $deleteStmt = $mysqli->prepare("DELETE FROM inventory WHERE inventory_id = ?");
                $deleteStmt->bind_param("s", $inventoryId);
                $deleteStmt->execute();
                $deleteStmt->close();
                
                echo "<br>"; // Add a line break for better readability
            } else {
                echo "Fetch failed: " . $stmt->error;
            }
        }
        break;
        

    case 'tab-4':
        foreach ($checkboxValues as $reservationId) {
            // Use prepared statements to prevent SQL injection
            $stmt = $mysqli->prepare("SELECT customers.customer_name, reservation_time, num_guests
                                        FROM reservations
                                        JOIN customers ON reservations.customer_id = customers.customer_id
                                        WHERE reservation_id = ?");
            $stmt->bind_param("s", $reservationId);
            $stmt->execute();
            $stmt->bind_result($customerName, $time, $num_guests);
            
            // Fetch customer_name and item_name
            if ($stmt->fetch()) {
                // Display the deleted order details
                echo "Deleted reservation ID: " . $reservationId . "<br>";
                echo "Item Name: " . $customerName . "<br>";
                echo "Quantity: " . $time . "<br>";
                echo "Quantity: " . $num_guests . "<br>";
    
                // Close the statement
                $stmt->close();
    
                // Delete the reservation
                $deleteStmt = $mysqli->prepare("DELETE FROM reservations WHERE reservation_id = ?");
                $deleteStmt->bind_param("s", $reservationId);
                $deleteStmt->execute();
                $deleteStmt->close();
                
                echo "<br>"; // Add a line break for better readability
            } else {
                echo "Fetch failed: " . $stmt->error;
            }
        }
        break;

    case 'tab-5':
        foreach ($checkboxValues as $staffId) {
            // Use prepared statements to prevent SQL injection
            $stmt = $mysqli->prepare("SELECT staff_name, staff_number, staff_email
                                        FROM staff                                        
                                        WHERE staff_id = ?");
            $stmt->bind_param("s", $staffId);
            $stmt->execute();
            $stmt->bind_result($staffName, $staffNumber, $staffEmail);
            
            // Fetch customer_name and item_name
            if ($stmt->fetch()) {
                // Display the deleted order details
                echo "Deleted staff ID: " . $staffId . "<br>";
                echo "Item Name: " . $staffName . "<br>";
                echo "Quantity: " . $staffNumber . "<br>";
                echo "Quantity: " . $staffEmail . "<br>";
    
                // Close the statement
                $stmt->close();
    
                // Delete the staff
                $deleteStmt = $mysqli->prepare("DELETE FROM staff WHERE staff_id = ?");
                $deleteStmt->bind_param("s", $staffId);
                $deleteStmt->execute();
                $deleteStmt->close();
                
                echo "<br>"; // Add a line break for better readability
            } else {
                echo "Fetch failed: " . $stmt->error;
            }
        }
        break;

    default:
        echo "Invalid tab ID";
        break;
}


// Close the database connection
$mysqli->close();
?>

<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>삭제 확인</title>

</head>
<body>
    <button type="button" onclick="goBack();">Go back</button>
    <script>
        // JavaScript를 사용하여 뒤로가기
        function goBack() {
            // 이전 페이지로 이동
            location.href = document.referrer;
        }
    </script>
</body>