<?php
// sql 연결, 음식점 이름 받아오기, email 받아오기
include('owner_info.php');

// 트랜잭션 시작
$mysqli->begin_transaction();

try {
// 음식점 이름으로 restaurant_id 찾기
$restaurantQuery = "SELECT restaurant_id FROM restaurants WHERE restaurant_name = ?";
$restaurantStmt = $mysqli->prepare($restaurantQuery);
$restaurantStmt->bind_param("s", $restaurant_name);
$restaurantStmt->execute();
$restaurantStmt->bind_result($restaurant_id);
$restaurantStmt->fetch();
$restaurantStmt->close();

// inventory table에서 알아낸 restaurant_id에 해당하는 데이터 가져오기
$inventoryQuery = "SELECT inventory_id, item_name, quantity
                   FROM inventory
                   WHERE restaurant_id = ?";

$inventoryStmt = $mysqli->prepare($inventoryQuery);
$inventoryStmt->bind_param("s", $restaurant_id);
$inventoryStmt->execute();
$inventoryResult = $inventoryStmt->get_result();

// 모든 쿼리가 성공하면 커밋
$mysqli->commit();

} catch (Exception $e) {
    // 쿼리 중 하나라도 실패하면 롤백
    $mysqli->rollback();
    echo "Transaction failed: " . $e->getMessage();
    }
    
    // 연결 해제
    $mysqli->close();
?>