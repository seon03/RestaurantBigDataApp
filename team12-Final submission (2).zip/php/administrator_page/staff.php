<?php
// sql 연결, 음식점 이름 받아오기, email 받아오기
include('owner_info.php');

// 음식점 이름으로 restaurant_id 찾기
$restaurantQuery = "SELECT restaurant_id FROM restaurants WHERE restaurant_name = ?";
$restaurantStmt = $mysqli->prepare($restaurantQuery);
$restaurantStmt->bind_param("s", $restaurant_name);
$restaurantStmt->execute();
$restaurantStmt->bind_result($restaurant_id);
$restaurantStmt->fetch();
$restaurantStmt->close();

// staff table에서 데이터 받아오기
$staffQuery = "SELECT staff.staff_id, staff.staff_name, staff.staff_number, staff.staff_email
               FROM staff               
               WHERE staff.restaurant_id = ?";
$staffStmt = $mysqli->prepare($staffQuery);
$staffStmt->bind_param("s", $restaurant_id); //주의-restaurant_id는 string
$staffStmt->execute();
$staffResult = $staffStmt->get_result();


// 연결 해제
$mysqli->close();
?>