<?php
// sql 연결, 음식점 이름 받아오기, email 받아오기
include('owner_info.php');

// 음식점 이름으로 restaurant_id 찾기
$restaurantQuery = "SELECT restaurant_id FROM restaurants WHERE restaurant_name = ?";
$restaurantStmt = $mysqli->prepare($restaurantQuery);
$restaurantStmt->bind_param("s", $restaurant_name);
$restaurantStmt->execute();
$restaurantStmt->bind_result($restaurant_id);
$restaurantStmt->fetch();
$restaurantStmt->close();

// reviews table에서 데이터 받아오기
$reviewsQuery = "SELECT reviews.review_id, reviews.comment, reviews.rating, customers.customer_name
               FROM reviews
               JOIN customers ON reviews.customer_id = customers.customer_id
               WHERE reviews.restaurant_id = ?";
$reviewsStmt = $mysqli->prepare($reviewsQuery);
$reviewsStmt->bind_param("s", $restaurant_id); //주의-restaurant_id는 string
$reviewsStmt->execute();
$reviewsResult = $reviewsStmt->get_result();

// 연결 해제
$mysqli->close();
?>