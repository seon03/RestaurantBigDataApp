<?php
// Include the file to get user information
include('order.php');
include('inventory.php');
include('review.php');
include('reservation.php');
include('staff.php');


?>

<!DOCTYPE html>
<html lang="ko">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Page</title>
    <style>
        body {
            margin-top: 10px;
            font-family: Arial, sans-serif;
            line-height: 1.6;
        }

        .container {
            width: 100%;
            margin: 0 auto;
        }

        .admin-info-button-container {
            display: flex;
            justify-content: space-between;
            width: 100%;
            margin-bottom: 20px;
        }

        .admin-info-box,
        .delete-button,
        .add-button,
        .update-button {
            width: 23%; /* Adjust the width as per your requirement */
        }

        .admin-info-box {
            border: 1px solid #ccc;
            padding: 10px;
            background-color: #f9f9f9;
        }

        .delete-button button,
        .add-button button,
        .update-button button {
            background-color: #87CEEB; /*연한 하늘색*/
            color: #fff;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-bottom: 20px;
            width: 100%; /* Make buttons fill the container width */
        }

        .delete-button button:hover,
        .add-button button:hover,
        .update-button button:hover {
            background-color: #5F9EA0; /* Darker shade of Light Sky Blue on hover */
        }

        .delete-button,
        .add-button {
            margin-right: 5px; /* Adjust the margin between Delete and Add buttons */
        }

        .add-button,
        .update-button {
            margin-right: 5px; /* Adjust the margin between Add and Update buttons */
        }

        h2 {
            margin-top: 0;
        }

        ul.tabs {
            margin: 0;
            padding: 0;
            list-style: none;
            overflow: hidden;
        }

        ul.tabs li {
            background: #3498db;
            color: white;
            display: inline-block;
            padding: 10px 15px;
            cursor: pointer;
            border-radius: 5px 5px 0 0;
        }

        ul.tabs li.current {
            background: #2c3e50;
            color: white;
        }

        .tab-content {
            display: none;
            background: #ededed;
            padding: 15px;
            border: 1px solid #ccc;
            border-radius: 0 0 5px 5px;
        }

        .tab-content.current {
            display: block;
        }

        .list {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .list th,
        .list td {
            height: 30px;
            text-align: center;
            border: 1px solid #e1e1e1;
            padding: 8px;
        }

        .list th {
            background-color: #3498db;
            color: white;
        }

        .list tr:nth-child(even) {
            background-color: #f9f9f9;
        }
    </style>
  
</head>

<body>

    <div class="container">
    <h2>Administrator page</h2>
        <div class="admin-info-button-container">
            <div class="admin-info-box">
                <p>Restaurant Name: <?php echo $restaurant_name; ?></p>
            </div>
            <div class="delete-button">
                <form id="deleteForm" method="post" action="delete.php">
                    <button type="submit" name="deleteButton" id="deleteButton">Delete</button>
                </form>
            </div>
            
            <div class="update-button">
                <form id="updateForm" method="post" action="update.php">                
                    <button type="button" name="updateButton" id="updateButton" onclick=updateData()>Update</button>
                </form>
            </div>
        </div>
      
        

        <ul class="tabs">
            <li class="tab-link current" data-tab="tab-1">Orders</li>
            <li class="tab-link" data-tab="tab-2">Inventory</li>
            <li class="tab-link" data-tab="tab-3">Reviews</li>
            <li class="tab-link" data-tab="tab-4">Reservations</li>
            <li class="tab-link" data-tab="tab-5">Employees</li>
        </ul>

        <div id="tab-1" class="tab-content current">
            <!-- order -->
            <table class="list" border="0" align="center" cellspacing="0" cellpadding="0">
                <colgroup>
                    <col width="5%" />
                    <col width="10%" />
                    <col width="15%" />
                    <col width="40%" />
                    <col width="10%" />
                    <col width="20%" />
                </colgroup>
                <tr>
                    <th>select</th>
                    <th>No</th>
                    <th>Customer</th>
                    <th>Menu</th>
                    <th>Quantity</th>
                    <th>Order Time</th>
                </tr>
                <tbody>
                    <?php
                    // Output orders
                    while ($orderRow = $orderResult->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td><input type='checkbox' name='selected_data[]' value='" . $orderRow['order_id'] . "' onclick='getCheckboxValue(event, \"tab-1\")'></td>";
                        echo "<td>" . $orderRow['order_id'] . "</td>";
                        echo "<td>" . $orderRow['customer_name'] . "</td>";
                        echo "<td>" . $orderRow['item_name'] . "</td>";
                        echo "<td>" . $orderRow['quantity'] . "</td>";
                        echo "<td>" . $orderRow['order_time'] . "</td>";
                        echo "</tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
        <div id="tab-2" class="tab-content">
            <!-- inventory -->
            <table class="list" border="0" align="center" cellspacing="0" cellpadding="0">
                <colgroup>
                    <col width="5%" />
                    <col width="10%" />
                    <col width="40%" />
                    <col width="10%" />
                </colgroup>
                <tr>
                    <th>select</th>
                    <th>No</th>
                    <th>Menu</th>                    
                    <th>Quantity</th>                    
                </tr>
                <tbody>
                    <?php
                    // Output inventory
                    while ($inventoryRow = $inventoryResult->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td><input type='checkbox' name='selected_data[]' value='" . $inventoryRow['inventory_id'] . "' onclick='getCheckboxValue(event, \"tab-2\")'></td>";
                        echo "<td>" . $inventoryRow['inventory_id'] . "</td>";
                        echo "<td>" . $inventoryRow['item_name'] . "</td>";
                        echo "<td>" . $inventoryRow['quantity'] . "</td>";                       
                        echo "</tr>";
                    }
                    
                    ?>
                </tbody>
            </table>
       </div>

        <div id="tab-3" class="tab-content">
            <!-- reviews -->
            <table class="list" border="0" align="center" cellspacing="0" cellpadding="0">
                <colgroup>
                    <col width="5%" />
                    <col width="10%" />
                    <col width="40%" />
                    <col width="10%" />
                    <col width="10%" />
                </colgroup>
                <tr>
                    <th>Select</th>
                    <th>No</th>
                    <th>Comment</th>                    
                    <th>Rating</th>  
                    <th>Writer</th>                      
                </tr>
                <tbody>
                    <?php
                    // Output reviews
                    while ($reviewsRow = $reviewsResult->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td><input type='checkbox' name='selected_data[]' value='" . $reviewsRow['review_id'] . "' onclick='getCheckboxValue(event, \"tab-3\")'></td>";
                        echo "<td>" . $reviewsRow['review_id'] . "</td>";
                        echo "<td>" . $reviewsRow['comment'] . "</td>";  
                        echo "<td>" . $reviewsRow['rating'] . "</td>";   
                        echo "<td>" . $reviewsRow['customer_name'] . "</td>";                  
                        echo "</tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
        <div id="tab-4" class="tab-content">
            <!-- reservations -->
            <table class="list" border="0" align="center" cellspacing="0" cellpadding="0">
                <colgroup>
                    <col width="5%" />
                    <col width="10%" />
                    <col width="30%" />
                    <col width="20%" />
                    <col width="10%" />
                </colgroup>
                <tr>
                    <th>Select</th>
                    <th>No</th>
                    <th>Reservation name</th>                    
                    <th>Time</th>  
                    <th>Number</th>                      
                </tr>
                <tbody>
                    <?php
                    // Output reservations
                    while ($reservationsRow = $reservationsResult->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td><input type='checkbox' name='selected_data[]' value='" . $reservationsRow['reservation_id'] . "' onclick='getCheckboxValue(event, \"tab-4\")'></td>";
                        echo "<td>" . $reservationsRow['reservation_id'] . "</td>";
                        echo "<td>" . $reservationsRow['customer_name'] . "</td>";  
                        echo "<td>" . $reservationsRow['reservation_time'] . "</td>";   
                        echo "<td>" . $reservationsRow['num_guests'] . "</td>";                  
                        echo "</tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
        <div id="tab-5" class="tab-content">
            <!-- staff -->
            <table class="list" border="0" align="center" cellspacing="0" cellpadding="0">
                <colgroup>
                    <col width="5%" />
                    <col width="10%" />
                    <col width="30%" />
                    <col width="20%" />
                    <col width="10%" />
                </colgroup>
                <tr>
                    <th>Select</th>
                    <th>No</th>
                    <th>Staff name</th>                    
                    <th>Staff phone number</th>  
                    <th>Staff email</th>                      
                </tr>
                <tbody>
                    <?php
                    // Output staff
                    while ($staffRow = $staffResult->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td><input type='checkbox' name='selected_data[]' value='" . $staffRow['staff_id'] . "' onclick='getCheckboxValue(event, \"tab-5\")'></td>";
                        echo "<td>" . $staffRow['staff_id'] . "</td>";
                        echo "<td>" . $staffRow['staff_name'] . "</td>";  
                        echo "<td>" . $staffRow['staff_number'] . "</td>";   
                        echo "<td>" . $staffRow['staff_email'] . "</td>";                  
                        echo "</tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


    <script>
        // 전역 변수 선언
        let TabId = '';
        let CheckboxValue = '';
        let Menu = '';
        let Quantity = '';
        let clickedTabId = '';

        function getCheckboxValue(event, tabId) {
            const checkboxes = document.querySelectorAll(`input[name="selected_data[]"]:checked`);
            let resultTabId = '';
            let resultCheckboxValue = '';

            checkboxes.forEach(function (checkbox, index) {
                resultTabId += tabId;
                resultCheckboxValue += checkbox.value;

                // Add a comma and space if it's not the last checkbox
                if (index < checkboxes.length - 1) {
                    resultTabId += ', ';
                    resultCheckboxValue += ', ';
                }
            });

            // 각각의 전역 변수에 저장
            TabId = resultTabId;
            CheckboxValue = resultCheckboxValue;

        }

        // 삭제 버튼 이벤트
        $('#deleteForm').submit(function (e) {
            e.preventDefault();

            if (clickedTabId == 'tab-3') {
                alert("You cannot delete the review!");
                
            }
            
            // 확인 팝업
            else {
                if (confirm("Are you sure you want to delete the selected data?")) {
                // Hidden input fields 생성 및 form에 추가
                const hiddenTabIdInput = document.createElement('input');
                hiddenTabIdInput.type = 'hidden';
                hiddenTabIdInput.name = 'selectedTabId';
                hiddenTabIdInput.value = TabId;
                this.appendChild(hiddenTabIdInput);

                const hiddenCheckboxValueInput = document.createElement('input');
                hiddenCheckboxValueInput.type = 'hidden';
                hiddenCheckboxValueInput.name = 'selectedCheckboxValue';
                hiddenCheckboxValueInput.value = CheckboxValue;
                this.appendChild(hiddenCheckboxValueInput);

                // Form 전송
                this.submit();
            }

            }
            
        });

    


        function getOrderQuantity() {
            // Input prompt
            alert("Please enter the quantity.");

            // Using prompt to get quantity
            const quantity = prompt("Enter the quantity:");
            const tabId = clickedTabId;

            // Check for entered quantity
            if (quantity !== null) {
                // Display entered quantity
                alert("Entered quantity: " + quantity);

                // Display confirmation dialog
                if (confirm("Do you want to update?")) {
                    // If the user clicks OK

                    // Create a form dynamically
                    const form = document.createElement('form');
                    form.method = 'post';
                    form.action = 'update.php';

                    // Create hidden input fields
                    const hiddenQuantityInput = document.createElement('input');
                    hiddenQuantityInput.type = 'hidden';
                    hiddenQuantityInput.name = 'quantity';
                    hiddenQuantityInput.value = quantity;
                    form.appendChild(hiddenQuantityInput);

                    const hiddenTabIdInput = document.createElement('input');
                    hiddenTabIdInput.type = 'hidden';
                    hiddenTabIdInput.name = 'tabId';
                    hiddenTabIdInput.value = tabId;
                    form.appendChild(hiddenTabIdInput);

                    const hiddenCheckboxValueInput = document.createElement('input');
                    hiddenCheckboxValueInput.type = 'hidden';
                    hiddenCheckboxValueInput.name = 'selectedCheckboxValue';
                    hiddenCheckboxValueInput.value = CheckboxValue;
                    form.appendChild(hiddenCheckboxValueInput);

                    // Append the form to the body and submit it
                    document.body.appendChild(form);
                    form.submit();
                } else {
                    // If the user clicks Cancel
                    alert("Operation canceled.");
                }
            } else {
                // If the user clicks Cancel in the input prompt
                alert("Operation canceled.");
            }
        }


        function getMenuAndQuantity() {
            // Input prompt
            alert("Please enter the menu and quantity.");

            // Using prompt to get menu and quantity
            const menu = prompt("Enter the menu:");
            const quantity = prompt("Enter the quantity:");
            const tabId = clickedTabId;

            // Check for entered menu and quantity
            if (menu !== null && quantity !== null) {
                // Display entered menu and quantity
                alert("Entered menu: " + menu + "\nEntered quantity: " + quantity);

                // Display confirmation dialog
                if (confirm("Do you want to update?")) {
                    // If the user clicks OK
                    
                    // Create a form dynamically
                    const form = document.createElement('form');
                    form.method = 'post';
                    form.action = 'update.php';

            
                    // Create hidden input fields
                    const hiddenMenuInput = document.createElement('input');
                    hiddenMenuInput.type = 'hidden';
                    hiddenMenuInput.name = 'menu';
                    hiddenMenuInput.value = menu;
                    form.appendChild(hiddenMenuInput);

                    const hiddenQuantityInput = document.createElement('input');
                    hiddenQuantityInput.type = 'hidden';
                    hiddenQuantityInput.name = 'quantity';
                    hiddenQuantityInput.value = quantity;
                    form.appendChild(hiddenQuantityInput);

                    const hiddenTabIdInput = document.createElement('input');
                    hiddenTabIdInput.type = 'hidden';
                    hiddenTabIdInput.name = 'tabId';
                    hiddenTabIdInput.value = tabId;
                    form.appendChild(hiddenTabIdInput);

                    const hiddenCheckboxValueInput = document.createElement('input');
                    hiddenCheckboxValueInput.type = 'hidden';
                    hiddenCheckboxValueInput.name = 'selectedCheckboxValue';
                    hiddenCheckboxValueInput.value = CheckboxValue;
                    form.appendChild(hiddenCheckboxValueInput);

                    // Append the form to the body and submit it
                    document.body.appendChild(form);
                    form.submit();
                } else {
                    // If the user clicks Cancel
                    alert("Operation canceled.");
                }
            } else {
                // If the user clicks Cancel in the input prompt
                alert("Operation canceled.");
            }
        }

        function getTimeAndGuests() {
            // Input prompt
            alert("Please enter the reservation time and number of reservations.");

            // Using prompt to get menu and quantity
            const time = prompt("Enter the reservation time(ex-13:10:10 :");
            const number = prompt("Enter the number of reservations :");
            const tabId = clickedTabId;

            // Check for entered menu and quantity
            if (time !== null && number !== null) {
                // Display entered menu and quantity
                alert("Entered reservation name: " + time + "\nEntered number of reservations: " + number);

                // Display confirmation dialog
                if (confirm("Do you want to update?")) {
                    // If the user clicks OK
                    
                    // Create a form dynamically
                    const form = document.createElement('form');
                    form.method = 'post';
                    form.action = 'update.php';

            
                    // Create hidden input fields
                    const hiddenTimeInput = document.createElement('input');
                    hiddenTimeInput.type = 'hidden';
                    hiddenTimeInput.name = 'time';
                    hiddenTimeInput.value = time;
                    form.appendChild(hiddenTimeInput);

                    const hiddenNumberInput = document.createElement('input');
                    hiddenNumberInput.type = 'hidden';
                    hiddenNumberInput.name = 'number';
                    hiddenNumberInput.value = number;
                    form.appendChild(hiddenNumberInput);

                    const hiddenTabIdInput = document.createElement('input');
                    hiddenTabIdInput.type = 'hidden';
                    hiddenTabIdInput.name = 'tabId';
                    hiddenTabIdInput.value = tabId;
                    form.appendChild(hiddenTabIdInput);

                    const hiddenCheckboxValueInput = document.createElement('input');
                    hiddenCheckboxValueInput.type = 'hidden';
                    hiddenCheckboxValueInput.name = 'selectedCheckboxValue';
                    hiddenCheckboxValueInput.value = CheckboxValue;
                    form.appendChild(hiddenCheckboxValueInput);

                    // Append the form to the body and submit it
                    document.body.appendChild(form);
                    form.submit();
                } else {
                    // If the user clicks Cancel
                    alert("Operation canceled.");
                }
            } else {
                // If the user clicks Cancel in the input prompt
                alert("Operation canceled.");
            }
        }

        function getNameAndPhone() {
            // Input prompt
            alert("Please enter the staff name and phone number.");

            // Using prompt to get staff name and phone number
            const staffName = prompt("Enter the staff name:");
            const staffPhone = prompt("Enter the staff phone number(ex-010-0000-0000):");
            const tabId = clickedTabId;

            // Check for entered values
            if (staffName !== null && staffPhone !== null) {
                // Display entered values
                alert("Entered staff name: " + staffName + "\nEntered staff phone number: " + staffPhone);

                // Display confirmation dialog
                if (confirm("Do you want to update?")) {
                    // If the user clicks OK
                    
                    // Create a form dynamically
                    const form = document.createElement('form');
                    form.method = 'post';
                    form.action = 'update.php';

                    // Create hidden input fields
                    const hiddenStaffNameInput = document.createElement('input');
                    hiddenStaffNameInput.type = 'hidden';
                    hiddenStaffNameInput.name = 'staffName';
                    hiddenStaffNameInput.value = staffName;
                    form.appendChild(hiddenStaffNameInput);

                    const hiddenStaffPhoneInput = document.createElement('input');
                    hiddenStaffPhoneInput.type = 'hidden';
                    hiddenStaffPhoneInput.name = 'staffPhone';
                    hiddenStaffPhoneInput.value = staffPhone;
                    form.appendChild(hiddenStaffPhoneInput);

                    const hiddenTabIdInput = document.createElement('input');
                    hiddenTabIdInput.type = 'hidden';
                    hiddenTabIdInput.name = 'tabId';
                    hiddenTabIdInput.value = tabId;
                    form.appendChild(hiddenTabIdInput);

                    const hiddenCheckboxValueInput = document.createElement('input');
                    hiddenCheckboxValueInput.type = 'hidden';
                    hiddenCheckboxValueInput.name = 'selectedCheckboxValue';
                    hiddenCheckboxValueInput.value = CheckboxValue;
                    form.appendChild(hiddenCheckboxValueInput);

                    // Append the form to the body and submit it
                    document.body.appendChild(form);
                    form.submit();
                } else {
                    // If the user clicks Cancel
                    alert("Operation canceled.");
                }
            } else {
                // If the user clicks Cancel in the input prompt
                alert("Operation canceled.");
            }
        }





        function updateData() {
            switch (clickedTabId) {
                case 'tab-1':
                    getOrderQuantity();
                    break;
                case 'tab-2':
                    getMenuAndQuantity();
                    break;
                case 'tab-3':
                    alert("You cannot change the review!");
                break;
                case 'tab-4':
                    getTimeAndGuests();
                    break;
                case 'tab-5':
                    getNameAndPhone();
                    break;
                default:
                    
                    break;
            }
            

        }

    </script>
     
    <script>
        $(document).ready(function () {
            // 초기 상태
            $('.tab-content').hide();
            $('.tab-content.current').show();            

            // 클릭 이벤트
            $('.tab-link').click(function () {
                // current 지우기
                $('.tab-link').removeClass('current');
                $('.tab-content').removeClass('current').hide();

                // 클릭된 tab을 current로 만들어 보이게 하기
                const tabId = $(this).data('tab');
                $(this).addClass('current');
                $('#' + tabId).addClass('current').fadeIn();

                clickedTabId = tabId;

                return false;
            });
            
        });
    </script>

</body>

</html>