<?php
// sql 연결, 음식점 이름 받아오기, email 받아오기
include('owner_info.php');

// 음식점 이름으로 restaurant_id 찾기
$restaurantQuery = "SELECT restaurant_id FROM restaurants WHERE restaurant_name = ?";
$restaurantStmt = $mysqli->prepare($restaurantQuery);
$restaurantStmt->bind_param("s", $restaurant_name);
$restaurantStmt->execute();
$restaurantStmt->bind_result($restaurant_id);
$restaurantStmt->fetch();
$restaurantStmt->close();

// Reservations table에서 데이터 받아오기
$reservationsQuery = "SELECT reservations.reservation_id, customers.customer_name, reservations.reservation_time, reservations.num_guests
                      FROM reservations
                      JOIN customers ON reservations.customer_id = customers.customer_id                      
                      WHERE reservations.restaurant_id = ?";

$reservationsStmt = $mysqli->prepare($reservationsQuery);
$reservationsStmt->bind_param("s", $restaurant_id); //주의-restaurant_id는 string
$reservationsStmt->execute();
$reservationsResult = $reservationsStmt->get_result();

// 연결 해제
$mysqli->close();
?>