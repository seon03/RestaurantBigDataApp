<?php
function paging($write_pages, $cur_page, $total_page, $url) {
    $str = "";
    if ($cur_page > 1) {
        $str .= "<a href='" . $url . "1' class='pre_all'>first</a>";
        $str .= "<a href='" . $url . ($cur_page-1) . "' class='pre'>pre</a>";
    } else {
        $str .= "";
    }
    $start_page = @( ( (int)( ($cur_page - 1 ) / $write_pages ) ) * $write_pages ) + 1;
    $end_page = $start_page + $write_pages - 1;

    if ($end_page >= $total_page) $end_page = $total_page;

    if ($total_page > 1) {
        for ($k=$start_page;$k<=$end_page;$k++) {
            if(($cur_page-2) <= $k  && $k < ($cur_page+3)) {
                if ($cur_page != $k) { 
                    $str .= "<a href='$url$k'  class='numBox;'>$k</a>";
                } else {
                    $str .= "<strong>$k</strong>"; 
                }
            }
        }
    }

    if ($cur_page < $total_page) {
        $str .= "<a href='$url" . ($cur_page+1) . "' class='next'>next</a>";
        $str .= "<a href='$url$total_page' class='next_all'>end</a>";
    } else {
        $str .= "";
    }

    $str .= "";

    return $str;
}
?>