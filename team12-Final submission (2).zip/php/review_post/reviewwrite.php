<?php

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $mysqli = new mysqli("localhost", "team12", "team12", "team12");

    if ($mysqli->connect_errno) {
        echo "Failed to connect to MySQL: " . $mysqli->connect_error;
        exit();
    }

    $userName = $_POST['userName'];
    $userEmail = $_POST['userEmail'];
    $restaurantName = $_POST['restaurantName'];
    $rating = $_POST['rating'];
    $reviewText = $_POST['reviewText'];

    // Get customer_id from Customers table
    $customerQuery = "SELECT customer_id FROM Customers WHERE customer_name='$userName' AND email='$userEmail'";
    $customerResult = $mysqli->query($customerQuery);

    if ($customerResult->num_rows > 0) {
        $customerRow = $customerResult->fetch_assoc();
        $customerID = $customerRow["customer_id"];

        // Get restaurant_id from Restaurants table
        $restaurantQuery = "SELECT restaurant_id FROM Restaurants WHERE restaurant_name='$restaurantName'";
        $restaurantResult = $mysqli->query($restaurantQuery);

        if ($restaurantResult->num_rows > 0) {
            $restaurantRow = $restaurantResult->fetch_assoc();
            $restaurantID = $restaurantRow["restaurant_id"];

            // Insert data into the Reviews table
            $sql = "INSERT INTO Reviews (restaurant_id, customer_id, rating, comment)
                    VALUES ('$restaurantID', '$customerID', $rating, '$reviewText')";

            if ($mysqli->query($sql) === TRUE) {
                echo "Review posted successfully!";
            } else {
                echo "Error: " . $sql . "<br>" . $mysqli->error;
            }
        } else {
            echo "Error: Restaurant not found.";
        }
    } else {
        echo "Error: Customer not found.";
    }

    // Close the database connection
    $mysqli->close();
}

?>

<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WriteReview</title>
    <link rel="stylesheet" type="text/css" href="review_style.css">
</head>
<body>

    <h1>Write a review</h1>

    <form class="review-form" method="post" action="reviewwrite.php">
        <label for="userName">Your Name:</label>
        <input type="text" name="userName" id="userName" class="review-input" required>

        <label for="userEmail">Your Email:</label>
        <input type="email" name="userEmail" id="userEmail" class="review-input" required>

        <label for="restaurantName">Restaurant name:</label>
        <input type="text" name="restaurantName" id="restaurantName" class="review-input" required>

        <label for="rating">rate:</label>
        <select name="rating" id="rating" class="review-input" required>
            <option value="1">1 point</option>
            <option value="2">2 points</option>
            <option value="3">3 points</option>
            <option value="4">4 points</option>
            <option value="5">5 points</option>
        </select>

        <label for="reviewText">Comment:</label>
        <textarea name="reviewText" id="reviewText" class="review-input" rows="4" required></textarea>

        <button type="button" class="review-button" onClick="location.href='../review_list_page/review_view.php'" >Post a review</button>
    </form>

</body>
</html>
