<!-- login.php -->

<?php
// MySQL 데이터베이스 연결
$mysqli = new mysqli("localhost", "team12", "team12", "team12");

// 연결 확인
if ($mysqli->connect_errno) {
    echo "Failed to connect to MySQL: " . $mysqli->connect_error;
    exit();
}

// 이메일 입력값 가져오기
$email = $_POST['userName'];

// Customers 테이블에서 이메일 검색
$query_customer = "SELECT customer_name FROM customers WHERE email = ?";
$stmt_customer = $mysqli->prepare($query_customer);
$stmt_customer->bind_param("s", $email);
$stmt_customer->execute();
$result_customer = $stmt_customer->get_result();

// Staff 테이블에서 이메일 검색
$query_staff = "SELECT staff_name FROM staff WHERE staff_email = ?";
$stmt_staff = $mysqli->prepare($query_staff);
$stmt_staff->bind_param("s", $email);
$stmt_staff->execute();
$result_staff = $stmt_staff->get_result();

// 사용자의 이름 표시
if ($result_customer->num_rows > 0) {
    // Customers 테이블에서 일치하는 정보가 있을 경우
    $row = $result_customer->fetch_assoc();
    $user_name = $row['customer_name'];
    // 세션에 사용자 이름 및 이메일 저장
    session_start();
    $_SESSION['user_name'] = $user_name;
    $_SESSION['user_email'] = $email; // Add this line to store the email in the session
    echo "안녕하세요, '$user_name'님!";
} elseif ($result_staff->num_rows > 0) {
    // Staff 테이블에서 일치하는 정보가 있을 경우
    $row = $result_staff->fetch_assoc();
    $user_name = $row['staff_name'];
    // 세션에 사용자 이름 및 이메일 저장
    session_start();
    $_SESSION['user_name'] = $user_name;
    $_SESSION['user_email'] = $email; // Add this line to store the email in the session
    echo "안녕하세요, '$user_name'님!";
} else {
    // 일치하는 정보가 없을 경우
    session_start();
    $_SESSION['user_name'] = "로그인 실패";
    $_SESSION['user_email'] = "가입된 이메일이 없습니다."; // Empty email in case of failure
    echo "일치하는 정보가 없습니다.";
}

// prepared statement 종료
$stmt_customer->close();
$stmt_staff->close();

// 데이터베이스 연결 종료
$mysqli->close();
?>

<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>검색 결과</title>

</head>
<body>
    <button type="button" class="back-button" onClick="location.href='../home_page/home.php'">Go back to home page</button>
</body>

