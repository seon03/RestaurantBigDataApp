

document.addEventListener("DOMContentLoaded", function() {
    // Check if the form exists before adding the event listener
    var loginForm = document.getElementById("login-form");
    
    if (loginForm) {
        loginForm.addEventListener("submit", function(event) {
            var email = document.getElementsByName("userName")[0].value;
            var password = document.getElementsByName("userPassword")[0].value;

            if (email === "" || password === "") {
                alert("Please enter both email and password.");
                event.preventDefault();
            }
        });
    } else {
        console.error("Login form not found. Check the form ID.");
    }
});
