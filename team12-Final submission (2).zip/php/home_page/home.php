<?php
// 세션 시작 - 로그인 후 환영 인사 띄우기 위함
session_start();
?>

<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>식당 데이터 분석 프로젝트</title>
    <link rel="stylesheet" href="home_style.css">
</head>
<body>

    <div class="left-content">
        <h1>Restaurant data analysis project</h1>

        <p>Welcome to our restaurant data analysis project!</p>

        <p>This project was developed to analyze restaurant data and provide useful information to users.</p>

        <p>Take a look at the main features of the project below.</p>

        <h2>Main functions</h2>

        <ul class="feature-list">
            <li>Function 1: View restaurant list</li>
            <li>Function 2: Check restaurant details</li>
            <li>Function 3: ordering food</li>
            <li>Function 4: Check payment and order history</li>
            <li>Function 5: Write a review</li>
            <li>Function 6: View reviews</li>
            <li>Function 7: Administrator function</li>
        </ul>
    </div>

    <div class="right-content">
        <div class="button-container">
            <div class="round-button" onClick="location.href='../restaurantList.php'">Go to<br>restaurants</div>
            <div class="round-button" onClick="location.href='../review_list_page/review_view.php'">To view<br>reviews</div>
            <div class="round-button" onClick="redirectToAdmin()">Administrator<br>function</div>
        </div>

        <script>
            function redirectToAdmin() {
                <?php
                // Check if user_email is set in the session
                if (isset($_SESSION['user_email'])) {
                    $user_email = $_SESSION['user_email'];
                } else {
                    $user_email = ""; // Default value if user_email is not set
                }
                ?>

                // Redirect to admin.php with the user_email as a query parameter
                window.location.href = `../administrator_page/admin.php?user_email=<?php echo $user_email; ?>`;
            }
        </script>

        <div class="login-wrapper">
            <h3>Login</h3>
            <form method="post" action="login.php" id="login-form">
                <input type="text" name="userName" placeholder="Email">
                <input type="submit" value="Login">
            </form>
            <!-- 세션이 설정되어 있으면 사용자 이름을 표시 -->
            <?php
            if (isset($_SESSION['user_name'])) {
                if($_SESSION['user_name'] == "로그인 실패") {
                    $user_name = $_SESSION['user_name'];
                    $user_email = $_SESSION['user_email'];
                    echo "<p>$user_name</p>";
                    echo "<p>Email: $user_email</p>";
                }
                else {
                    $user_name = $_SESSION['user_name'];
                    $user_email = $_SESSION['user_email'];
                    echo "<p>Hello, '$user_name' !</p>";
                    echo "<p>Email: $user_email</p>";
                }
                
            }
            ?>
            
        
        </div>
        
        <button type="button" class="signup-button" onClick="location.href='../signup/guest_register.php'">Sign up as a guest</button>
            <button type="button" class="signup-button" onClick="location.href='../signup/owner_register.php'">Sign up as a restaurant owner</button>
    </div>
    
</body>
</html>
