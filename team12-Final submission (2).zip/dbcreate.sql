USE team12;

CREATE TABLE Restaurants
(
	restaurant_id	VARCHAR(512) PRIMARY KEY,
	restaurant_name	VARCHAR(512),
	location	VARCHAR(512),
	phone	VARCHAR(512)
);

CREATE TABLE Menu
(
	menu_id	VARCHAR(512) PRIMARY KEY,
	restaurant_id	VARCHAR(512),
	item_name	VARCHAR(512),
	description	VARCHAR(512),
	price	INT NOT NULL,

	FOREIGN KEY (restaurant_id) REFERENCES Restaurants(restaurant_id)
);

create table Customers
(
	customer_id VARCHAR(255) PRIMARY KEY,
	customer_name varchar(255) NOT NULL,
	email varchar(255) NOT NULL,
	phone varchar(255) NOT NULL
);

CREATE TABLE Orders
(
	order_id	VARCHAR(512) PRIMARY KEY,
	customer_id	VARCHAR(512),
	restaurant_id	VARCHAR(512),
	menu_id	VARCHAR(512),
	quantity	INT NOT NULL,
	order_time	VARCHAR(512),

	FOREIGN KEY (customer_id) REFERENCES Customers(customer_id),
	FOREIGN KEY (restaurant_id) REFERENCES Restaurants(restaurant_id),
	FOREIGN KEY (menu_id) REFERENCES Menu(menu_id) ON UPDATE CASCADE
);

CREATE TABLE Reviews
(
	review_id	VARCHAR(512) PRIMARY KEY,
	restaurant_id	VARCHAR(512),
	customer_id	VARCHAR(512),
	rating	INT NOT NULL,
	comment	VARCHAR(512),

	FOREIGN KEY (restaurant_id) REFERENCES Restaurants(restaurant_id),
	FOREIGN KEY (customer_id) REFERENCES Customers(customer_id)
);

create table Payments
(
	payment_id varchar(255) PRIMARY KEY,
	order_id varchar(255) NOT NULL, 
	amount INT NOT NULL,
	payment_time TIME NOT NULL,

	FOREIGN KEY (order_id) REFERENCES Orders (order_id)
);

create table Reservations
(
	reservation_id varchar(255) PRIMARY KEY,
	customer_id varchar(255) NOT NULL,
	restaurant_id varchar(255) NOT NULL, 
	reservation_time varchar(255) NOT NULL,
	num_guests INT NOT NULL,

	FOREIGN KEY (customer_id) REFERENCES Customers (customer_id),
	FOREIGN KEY (restaurant_id) REFERENCES Restaurants (restaurant_id)
);



create table Staff
(
	staff_id varchar(255) PRIMARY KEY,
	restaurant_id varchar(255) NOT NULL,
	staff_name varchar(255) NOT NULL,
	staff_number varchar(255) NOT NULL,
	staff_email varchar(255) NOT NULL,

	FOREIGN KEY (restaurant_id) REFERENCES Restaurants (restaurant_id)
);

CREATE TABLE Category 
(
    category_id VARCHAR(15) PRIMARY KEY,
    category_name VARCHAR(20) NOT NULL,
    restaurant_id VARCHAR(20) NOT NULL,
    
    FOREIGN KEY (restaurant_id) REFERENCES Restaurants(restaurant_id) ON DELETE CASCADE
);

CREATE TABLE Ranking (
    ranking_id VARCHAR(15) PRIMARY KEY,
    restaurant_id VARCHAR(20) NOT NULL,
    rank_date DATE NOT NULL,
    score INT NOT NULL,
    
    FOREIGN KEY (restaurant_id) REFERENCES Restaurants(restaurant_id) ON DELETE CASCADE
);

CREATE TABLE Inventory (
    inventory_id VARCHAR(15) PRIMARY KEY,
    restaurant_id VARCHAR(20) NOT NULL,
    menu_id VARCHAR(10) NOT NULL,
    item_name VARCHAR(50) NOT NULL,
    quantity INT NOT NULL,
    
    FOREIGN KEY (restaurant_id) REFERENCES Restaurants(restaurant_id) ON DELETE CASCADE,
    FOREIGN KEY (menu_id) REFERENCES Menu(menu_id) ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE Discount (
    discount_id VARCHAR(15) PRIMARY KEY,
    restaurant_id VARCHAR(20) NOT NULL,
    discount_percentage INT NOT NULL,
    description VARCHAR(10) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    
    FOREIGN KEY (restaurant_id) REFERENCES Restaurants(restaurant_id) ON DELETE CASCADE
);